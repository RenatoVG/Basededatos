<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$internacional = [
"titulo" => "XXX",
"autor" => "XXX",
"resumen" => "XXX",
];
?>
