<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$portada = [
"titulo" => "La portada CC2022",
"autor" => "mtorres",
"resumen" => "El resumen maravilloso",
];
?>
